import React, { useState } from 'react';
import { SKILL_CATEGORIES } from '../data/skills';
import { Layers, Server, Cpu, Zap, Wrench } from 'lucide-react';

export const Skills: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');

  const tabs = [
    { id: 'all', label: 'All Technologies' },
    { id: 'frontend', label: 'Frontend' },
    { id: 'backend', label: 'Backend & APIs' },
    { id: 'ai', label: 'AI Integration' },
    { id: 'automation', label: 'Automation' },
    { id: 'tools', label: 'Tools & Other' },
  ];

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'frontend':
        return <Layers className="w-4 h-4 text-[#D4A373]" />;
      case 'backend':
        return <Server className="w-4 h-4 text-[#D4A373]" />;
      case 'ai':
        return <Cpu className="w-4 h-4 text-[#D4A373]" />;
      case 'automation':
        return <Zap className="w-4 h-4 text-[#D4A373]" />;
      default:
        return <Wrench className="w-4 h-4 text-[#D4A373]" />;
    }
  };

  const filteredCategories =
    activeTab === 'all'
      ? SKILL_CATEGORIES
      : SKILL_CATEGORIES.filter((cat) => cat.id === activeTab);

  return (
    <section id="skills" className="py-20 bg-[#111215]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
            Technical Stack
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight">
            Tools and technologies I use to build.
          </h2>
          <p className="text-sm text-[#9DA2AC] mt-2">
            Honest representation of practical working skills. Clean technology breakdown without fabricated metrics.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-8 no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-1.5 text-xs font-mono-custom tracking-wider rounded-md whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-[#F1F1EF] text-[#111215] font-bold shadow-sm'
                  : 'bg-[#16171B] text-[#9DA2AC] hover:text-[#F1F1EF] hover:bg-[#1D1F25] border border-[#262830]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCategories.map((cat) => (
            <div
              key={cat.id}
              className="p-5 rounded-xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5 mb-2">
                  <div className="p-1.5 rounded-md bg-[#1B1D23] border border-[#2E323D]">
                    {getCategoryIcon(cat.id)}
                  </div>
                  <h3 className="text-sm font-semibold text-[#F1F1EF] tracking-tight">{cat.title}</h3>
                </div>

                <p className="text-xs text-[#9DA2AC] mb-4 leading-relaxed">
                  {cat.description}
                </p>

                {/* Skill Items as clean tags */}
                <div className="flex flex-wrap gap-2">
                  {cat.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md border ${
                        skill.highlight
                          ? 'bg-[#1B1D23] text-[#F1F1EF] border-[#2E323D] font-medium'
                          : 'bg-[#111215] text-[#9DA2AC] border-[#262830]'
                      }`}
                    >
                      <span>{skill.name}</span>
                      {skill.note && (
                        <span className="text-[10px] font-mono-custom text-[#D4A373] bg-[#D4A373]/10 px-1 py-0.2 rounded border border-[#D4A373]/25">
                          {skill.note}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom tag identifier */}
              <div className="mt-5 pt-3 border-t border-[#262830] flex items-center justify-between text-[11px] font-mono-custom text-[#686D78]">
                <span>{cat.skills.length} competencies</span>
                <span>Practical stack</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

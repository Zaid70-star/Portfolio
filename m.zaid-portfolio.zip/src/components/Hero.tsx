import React, { useState, useEffect } from 'react';
import { ArrowDown, ArrowUpRight, Github, Linkedin, Upload, MapPin, GraduationCap, Code2, Sparkles, Workflow } from 'lucide-react';

export const Hero: React.FC = () => {
  const [photoSrc, setPhotoSrc] = useState<string | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('zaid_portfolio_avatar');
      if (saved) {
        setPhotoSrc(saved);
      }
    } catch {
      // ignore
    }
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setPhotoSrc(result);
          try {
            localStorage.setItem('zaid_portfolio_avatar', result);
          } catch {
            // ignore
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="home" className="relative pt-28 pb-20 md:pt-36 md:pb-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Main Hero Copy (Cols 1-7) */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Availability Indicator - low saturation sage / olive */}
            <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-mono-custom text-[#A8C5A0] bg-[#A8C5A0]/10 border border-[#A8C5A0]/25 rounded-full mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-[#A8C5A0]" />
              <span>Available for Freelance Projects</span>
            </div>

            {/* Location & Role Kicker */}
            <p className="text-xs uppercase tracking-widest text-[#9DA2AC] font-mono-custom mb-3">
              Lahore, Pakistan · Frontend &amp; Automation
            </p>

            {/* Main Headline with warm bronze accent */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F1F1EF] leading-[1.18] mb-6">
              Building Modern Web Experiences with{' '}
              <span className="text-[#D4A373]">
                AI &amp; Automation.
              </span>
            </h1>

            {/* Supporting Paragraph */}
            <p className="text-base sm:text-lg text-[#9DA2AC] leading-relaxed mb-8 max-w-2xl">
              I’m <span className="text-[#F1F1EF] font-medium">Muhammad Zaid</span>, a frontend developer focused on React, AI integrations, and workflow automation. I build practical digital solutions that help businesses improve their online presence and automate repetitive work.
            </p>

            {/* Value Proposition Highlights in Warm Charcoal Surfaces */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-xl mb-8">
              <div className="p-3 bg-[#16171B] border border-[#262830] rounded-lg flex items-start gap-2.5">
                <Code2 className="w-4 h-4 text-[#D4A373] mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-[#F1F1EF]">Modern Websites</p>
                  <p className="text-[11px] text-[#9DA2AC]">React, Tailwind &amp; APIs</p>
                </div>
              </div>
              <div className="p-3 bg-[#16171B] border border-[#262830] rounded-lg flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-[#D4A373] mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-[#F1F1EF]">AI Features</p>
                  <p className="text-[11px] text-[#9DA2AC]">Gemini API &amp; FastAPI</p>
                </div>
              </div>
              <div className="p-3 bg-[#16171B] border border-[#262830] rounded-lg flex items-start gap-2.5">
                <Workflow className="w-4 h-4 text-[#A8C5A0] mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-[#F1F1EF]">Automation</p>
                  <p className="text-[11px] text-[#9DA2AC]">n8n, Webhooks &amp; APIs</p>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto mb-8">
              <a
                href="#projects"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-lg transition-all shadow-sm active:translate-y-0.5"
              >
                <span>View My Work</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </a>

              <a
                href="#contact"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#F1F1EF] bg-[#16171B] hover:bg-[#1D1F25] rounded-lg border border-[#262830] hover:border-[#383C48] transition-all active:translate-y-0.5"
              >
                <span>Let's Work Together</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Social & Direct Contact Links */}
            <div className="flex items-center gap-4 text-xs font-mono-custom text-[#9DA2AC]">
              <a
                href="https://github.com/Zaid70-star"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 hover:text-[#D4A373] transition-colors"
              >
                <Github className="w-3.5 h-3.5" />
                <span>github.com/Zaid70-star</span>
              </a>
              <span className="text-[#383C48]" aria-hidden="true">/</span>
              <a
                href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 hover:text-[#D4A373] transition-colors"
              >
                <Linkedin className="w-3.5 h-3.5" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>

          {/* Profile Card / Photo Frame (Cols 8-12) */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full max-w-sm bg-[#16171B] p-1.5 rounded-2xl border border-[#262830] shadow-xl">
              <div className="bg-[#111215] rounded-xl p-5 flex flex-col items-center">
                {/* Photo Display / Monogram */}
                <div className="relative group w-48 h-48 sm:w-56 sm:h-56 rounded-xl overflow-hidden bg-[#16171B] border border-[#262830] mb-5 flex items-center justify-center">
                  {photoSrc ? (
                    <img
                      src={photoSrc}
                      alt="Muhammad Zaid — Frontend Developer"
                      className="w-full h-full object-cover object-top"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center p-4 text-center">
                      <div className="w-16 h-16 rounded-full bg-[#1B1D23] border border-[#2E323D] flex items-center justify-center text-[#D4A373] font-mono-custom text-xl font-bold mb-2">
                        MZ.
                      </div>
                      <span className="text-[11px] font-mono-custom tracking-wider text-[#9DA2AC] uppercase">
                        [PROFILE PHOTO]
                      </span>
                      <p className="text-xs text-[#F1F1EF] font-semibold mt-1">Muhammad Zaid</p>
                      <p className="text-[11px] text-[#686D78] mt-1">Lahore, Pakistan</p>
                    </div>
                  )}

                  {/* Photo Upload Action Overlay */}
                  <label
                    htmlFor="avatar-upload"
                    className="absolute inset-0 bg-[#111215]/85 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer p-3 text-center text-white text-xs gap-1.5 backdrop-blur-xs"
                    title="Upload or change profile portrait"
                  >
                    <Upload className="w-5 h-5 text-[#D4A373]" />
                    <span className="font-medium text-[#F1F1EF]">Update Photo</span>
                    <span className="text-[10px] text-[#9DA2AC]">JPG, PNG, WebP</span>
                  </label>
                  <input
                    id="avatar-upload"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>

                {/* Identity Summary Info */}
                <div className="text-center w-full">
                  <h2 className="text-lg font-bold text-[#F1F1EF] tracking-tight">Muhammad Zaid</h2>
                  <p className="text-xs text-[#D4A373] font-mono-custom mt-0.5">
                    Frontend Developer | AI Integration | Automation
                  </p>

                  <div className="mt-4 pt-4 border-t border-[#262830] flex flex-col gap-2 text-left w-full text-xs text-[#9DA2AC]">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#686D78] shrink-0" />
                      <span>Lahore, Pakistan</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-3.5 h-3.5 text-[#686D78] shrink-0" />
                      <span>BSCS Student at UET Lahore</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Caption */}
            <p className="text-[11px] text-[#686D78] mt-3 font-mono-custom text-center">
              Verified identity · Codebases hosted on GitHub
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

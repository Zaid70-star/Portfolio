import React, { useState } from 'react';
import { FEATURED_PROJECTS } from '../data/projects';
import { ExternalLink, Github, Check, Code, Layers, Bot, Workflow, Image as ImageIcon } from 'lucide-react';

export const Projects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [customScreenshots, setCustomScreenshots] = useState<Record<string, string>>({});

  const filterTabs = [
    { id: 'all', label: 'All Projects' },
    { id: 'web', label: 'Web Applications' },
    { id: 'ai', label: 'AI Integrations' },
    { id: 'automation', label: 'Automations' },
  ];

  const filteredProjects =
    activeCategory === 'all'
      ? FEATURED_PROJECTS
      : FEATURED_PROJECTS.filter((p) => p.category === activeCategory);

  const handleImageUpload = (projectId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setCustomScreenshots((prev) => ({ ...prev, [projectId]: result }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'web':
        return <Layers className="w-3.5 h-3.5 text-[#D4A373]" />;
      case 'ai':
        return <Bot className="w-3.5 h-3.5 text-[#D4A373]" />;
      case 'automation':
        return <Workflow className="w-3.5 h-3.5 text-[#A8C5A0]" />;
      default:
        return <Code className="w-3.5 h-3.5 text-[#9DA2AC]" />;
    }
  };

  return (
    <section id="projects" className="py-20 bg-[#131418] border-y border-[#262830]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div className="max-w-2xl">
            <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
              Featured Work
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight">
              Real projects built with React, AI APIs &amp; automation.
            </h2>
            <p className="text-sm text-[#9DA2AC] mt-2">
              Clean architectures with verified GitHub repositories and live deployments.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-[#16171B] rounded-lg border border-[#262830] self-start md:self-auto">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveCategory(tab.id)}
                className={`px-3 py-1.5 text-xs font-mono-custom rounded-md transition-all ${
                  activeCategory === tab.id
                    ? 'bg-[#F1F1EF] text-[#111215] font-bold shadow-sm'
                    : 'text-[#9DA2AC] hover:text-[#F1F1EF]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredProjects.map((project) => {
            const uploadedImg = customScreenshots[project.id];

            return (
              <div
                key={project.id}
                className="group rounded-2xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden"
              >
                {/* Visual Preview / Architecture Container */}
                <div className="relative w-full h-52 bg-[#111215] border-b border-[#262830] p-5 flex flex-col justify-between overflow-hidden">
                  {uploadedImg ? (
                    <img
                      src={uploadedImg}
                      alt={`${project.name} screenshot`}
                      className="absolute inset-0 w-full h-full object-cover object-top"
                    />
                  ) : (
                    <>
                      {/* Top Bar inside preview */}
                      <div className="flex items-center justify-between z-10">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#262830]" />
                          <span className="w-2.5 h-2.5 rounded-full bg-[#262830]" />
                          <span className="w-2.5 h-2.5 rounded-full bg-[#262830]" />
                          <span className="text-[11px] font-mono-custom text-[#686D78] ml-2">
                            {project.id}
                          </span>
                        </div>

                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono-custom text-[#F1F1EF] bg-[#1B1D23] rounded border border-[#2E323D]">
                          {getCategoryIcon(project.category)}
                          <span className="capitalize">{project.category}</span>
                        </div>
                      </div>

                      {/* Middle Architecture Schematic */}
                      <div className="my-auto z-10">
                        <div className="p-3 rounded-lg bg-[#16171B] border border-[#262830] max-w-sm">
                          <p className="text-[11px] font-mono-custom text-[#D4A373] mb-1">
                            Architecture Workflow
                          </p>
                          <p className="text-xs text-[#F1F1EF] font-medium">
                            {project.architectureNotes || 'Component Tree & State Logic'}
                          </p>
                        </div>
                      </div>

                      {/* Bottom Bar: Quick tech summary */}
                      <div className="flex items-center justify-between z-10 text-[11px] text-[#9DA2AC]">
                        <span className="font-mono-custom text-[#686D78]">
                          Production Ready
                        </span>

                        {/* Optional upload screenshot affordance */}
                        <label
                          htmlFor={`upload-${project.id}`}
                          className="inline-flex items-center gap-1 text-[11px] text-[#9DA2AC] hover:text-[#F1F1EF] cursor-pointer bg-[#1B1D23] px-2 py-0.5 rounded border border-[#2E323D] transition-colors"
                          title="Attach custom screenshot"
                        >
                          <ImageIcon className="w-3 h-3 text-[#9DA2AC]" />
                          <span>Attach Screen</span>
                        </label>
                        <input
                          id={`upload-${project.id}`}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(project.id, e)}
                          className="hidden"
                        />
                      </div>
                    </>
                  )}
                </div>

                {/* Project Body */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Title & Tagline */}
                    <div className="mb-3">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-lg font-bold text-[#F1F1EF] group-hover:text-[#D4A373] transition-colors">
                          {project.name}
                        </h3>
                        {project.badge && (
                          <span className="text-[10px] font-mono-custom text-[#A8C5A0] bg-[#A8C5A0]/10 border border-[#A8C5A0]/25 px-2 py-0.5 rounded-full">
                            {project.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#9DA2AC] font-mono-custom mt-0.5">
                        {project.tagline}
                      </p>
                    </div>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-[#9DA2AC] leading-relaxed mb-4">
                      {project.description}
                    </p>

                    {/* Key Features */}
                    <div className="mb-5 space-y-1.5">
                      <p className="text-[11px] uppercase font-mono-custom text-[#686D78] tracking-wider">
                        Key Features
                      </p>
                      {project.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-[#9DA2AC]">
                          <Check className="w-3.5 h-3.5 text-[#D4A373] mt-0.5 shrink-0" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>

                    {/* Technology Tags */}
                    <div className="mb-6">
                      <div className="flex flex-wrap gap-1.5">
                        {project.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="text-[11px] font-mono-custom px-2 py-0.5 rounded bg-[#111215] text-[#9DA2AC] border border-[#262830]"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Action Links */}
                  <div className="pt-4 border-t border-[#262830] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      {project.githubUrl ? (
                        <a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#F1F1EF] bg-[#16171B] hover:bg-[#1D1F25] hover:text-white rounded-md border border-[#262830] hover:border-[#383C48] transition-colors"
                        >
                          <Github className="w-3.5 h-3.5" />
                          <span>Code Repository</span>
                        </a>
                      ) : (
                        <span className="text-xs text-[#686D78] font-mono-custom">
                          Repo available on inquiry
                        </span>
                      )}

                      {project.demoUrl && (
                        <a
                          href={project.demoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-md transition-colors"
                        >
                          <span>Live Demo</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    <span className="text-[11px] font-mono-custom text-[#686D78]">
                      Zaid70-star
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

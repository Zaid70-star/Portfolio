import React from 'react';
import { SERVICES } from '../data/services';
import { Layout, BotMessageSquare, Sparkles, Workflow, Cpu, Palette, ArrowRight } from 'lucide-react';

export const Services: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-5 h-5 text-[#D4A373]" />;
      case 'BotMessageSquare':
        return <BotMessageSquare className="w-5 h-5 text-[#D4A373]" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#D4A373]" />;
      case 'Workflow':
        return <Workflow className="w-5 h-5 text-[#D4A373]" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-[#D4A373]" />;
      case 'Palette':
        return <Palette className="w-5 h-5 text-[#D4A373]" />;
      default:
        return <Layout className="w-5 h-5 text-[#D4A373]" />;
    }
  };

  return (
    <section id="services" className="py-20 bg-[#111215]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
            Services &amp; Capabilities
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight">
            How I can help your web project or business.
          </h2>
          <p className="text-sm text-[#9DA2AC] mt-2">
            Clear problem-solving mapped directly to my actual technical competencies.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="p-6 rounded-xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] transition-all flex flex-col justify-between"
            >
              <div>
                {/* Service Header */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 rounded-lg bg-[#1B1D23] border border-[#2E323D] shrink-0">
                    {getIcon(service.icon)}
                  </div>
                  <h3 className="text-base font-semibold text-[#F1F1EF] tracking-tight">
                    {service.title}
                  </h3>
                </div>

                {/* Problem Block */}
                <div className="mb-4">
                  <span className="text-[11px] font-mono-custom text-[#D97D64] uppercase tracking-wider block mb-1">
                    Problem
                  </span>
                  <p className="text-xs text-[#9DA2AC] leading-relaxed">
                    {service.problem}
                  </p>
                </div>

                {/* Solution Block */}
                <div className="mb-5">
                  <span className="text-[11px] font-mono-custom text-[#A8C5A0] uppercase tracking-wider block mb-1">
                    Solution
                  </span>
                  <p className="text-xs text-[#F1F1EF] leading-relaxed font-medium">
                    {service.solution}
                  </p>
                </div>
              </div>

              {/* Technology Tags */}
              <div className="pt-4 border-t border-[#262830]">
                <span className="text-[10px] font-mono-custom text-[#686D78] uppercase tracking-wider block mb-1.5">
                  Technologies Used
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {service.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="text-[11px] font-mono-custom px-2 py-0.5 rounded bg-[#111215] text-[#9DA2AC] border border-[#262830]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick CTA banner */}
        <div className="mt-12 p-6 rounded-2xl bg-[#16171B] border border-[#262830] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-sm sm:text-base font-semibold text-[#F1F1EF]">
              Need a custom combination of website, AI, or automation?
            </h4>
            <p className="text-xs text-[#9DA2AC] mt-1">
              I can build custom integrations tailored to your existing systems.
            </p>
          </div>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-md transition-all shrink-0"
          >
            <span>Inquire About A Project</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { Layers, Bot, Zap, CheckCircle2 } from 'lucide-react';

export const About: React.FC = () => {
  const whatICanBuild = [
    {
      title: 'Modern Web Frontends',
      description:
        'Single-page and responsive web applications built with React, Vite, and Tailwind CSS, featuring structured component hierarchies and smooth routing.',
      icon: Layers,
    },
    {
      title: 'AI-Connected Interfaces',
      description:
        'Web portals and chat interfaces connected to Python/FastAPI microservices and the Google Gemini API, using prompt engineering for structured responses.',
      icon: Bot,
    },
    {
      title: 'Operational Automations',
      description:
        'Automated workflows engineered with n8n and webhooks to eliminate repetitive data handling, route notifications, and connect third-party platforms.',
      icon: Zap,
    },
  ];

  return (
    <section id="about" className="py-20 bg-[#131418] border-y border-[#262830]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
            About Me
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight">
            Practical engineering for real web and business needs.
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Narrative Prose */}
          <div className="lg:col-span-7 space-y-5 text-[#9DA2AC] text-base leading-relaxed">
            <p>
              I am a Computer Science undergraduate at the <strong className="text-[#F1F1EF] font-medium">University of Engineering and Technology (UET), Lahore</strong>, building practical software solutions across modern frontend engineering, REST API integrations, and workflow automation.
            </p>

            <p>
              Rather than theoretical concepts alone, my work centers on building tangible software that people can interact with. In frontend development, I build component-driven interfaces using <span className="text-[#F1F1EF] font-medium">React</span> and <span className="text-[#F1F1EF] font-medium">Tailwind CSS</span>, prioritizing performance, clean typography, and responsive ergonomics.
            </p>

            <p>
              On the backend and automation side, I implement <span className="text-[#F1F1EF] font-medium">Python &amp; FastAPI</span> endpoints to interface with the <span className="text-[#F1F1EF] font-medium">Gemini API</span>, and create <span className="text-[#F1F1EF] font-medium">n8n</span> workflows that streamline everyday tasks for businesses and creators.
            </p>

            {/* Quick Commitments List */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-[#9DA2AC]">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4A373] mt-1 shrink-0" />
                <span>Responsive &amp; accessible interfaces</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4A373] mt-1 shrink-0" />
                <span>Clean, maintainable component code</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4A373] mt-1 shrink-0" />
                <span>Realistic AI &amp; API implementations</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4A373] mt-1 shrink-0" />
                <span>Honest, reliable communication</span>
              </div>
            </div>
          </div>

          {/* Right Column: "What I Build" Focus Cards */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-xs uppercase font-mono-custom text-[#686D78] tracking-wider">
              Core Capabilities
            </h3>

            {whatICanBuild.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="p-5 bg-[#16171B] border border-[#262830] rounded-xl hover:border-[#383C48] transition-colors"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-[#1B1D23] text-[#D4A373] border border-[#2E323D]">
                      <Icon className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-semibold text-[#F1F1EF]">{item.title}</h4>
                  </div>
                  <p className="text-xs text-[#9DA2AC] leading-relaxed pl-11">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { Menu, X, Github, Linkedin, ArrowUpRight } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const navLinks = [
    { name: 'HOME', href: '#home', id: 'home' },
    { name: 'ABOUT', href: '#about', id: 'about' },
    { name: 'SKILLS', href: '#skills', id: 'skills' },
    { name: 'PROJECTS', href: '#projects', id: 'projects' },
    { name: 'SERVICES', href: '#services', id: 'services' },
    { name: 'LEARNING', href: '#building', id: 'building' },
    { name: 'CONTACT', href: '#contact', id: 'contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Scroll spy for active navigation item
      const sections = ['home', 'about', 'skills', 'projects', 'services', 'building', 'contact'];
      const scrollPos = window.scrollY + 140;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
        isScrolled
          ? 'bg-[#111215]/95 backdrop-blur-md border-b border-[#262830] shadow-md'
          : 'bg-[#111215]/60 backdrop-blur-xs border-b border-[#262830]/40'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Brand Wordmark */}
          <a
            href="#home"
            className="group flex items-center gap-2.5 text-[#F1F1EF] font-semibold text-base tracking-tight hover:text-white transition-colors"
          >
            <span className="w-8 h-8 rounded bg-[#1B1D23] border border-[#2E323D] text-[#D4A373] font-mono-custom text-xs font-bold flex items-center justify-center group-hover:border-[#D4A373]/60 transition-colors">
              MZ.
            </span>
            <div className="flex flex-col">
              <span className="font-bold tracking-tight text-sm sm:text-base leading-none text-[#F1F1EF]">
                Muhammad Zaid
              </span>
              <span className="text-[10px] font-mono-custom text-[#9DA2AC] leading-tight mt-0.5 tracking-wider uppercase">
                Lahore, Pakistan
              </span>
            </div>
          </a>

          {/* Desktop & Tablet Navigation: prominent, tracked uppercase links */}
          <nav className="hidden md:flex items-center gap-1 sm:gap-2">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  className={`px-2.5 sm:px-3 py-1.5 text-[11px] font-mono-custom tracking-wider transition-colors relative group ${
                    isActive
                      ? 'text-[#F1F1EF] font-semibold'
                      : 'text-[#9DA2AC] hover:text-[#F1F1EF]'
                  }`}
                >
                  {link.name}
                  {isActive ? (
                    <span className="absolute bottom-0 left-2.5 right-2.5 h-[2px] bg-[#D4A373] rounded-full" />
                  ) : (
                    <span className="absolute bottom-0 left-2.5 right-2.5 h-[1.5px] bg-[#383C48] scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-150" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Desktop Right Actions: Social + CTA */}
          <div className="hidden sm:flex items-center gap-2.5">
            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] hover:bg-[#1A1C22] rounded-md border border-[#262830] transition-colors"
              title="GitHub Profile (Zaid70-star)"
              aria-label="GitHub Profile"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] hover:bg-[#1A1C22] rounded-md border border-[#262830] transition-colors"
              title="LinkedIn Profile"
              aria-label="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href="#contact"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-md transition-all active:translate-y-0.5 shadow-sm"
            >
              <span>Let's Talk</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile Header Controls */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] rounded-md border border-[#262830]"
              aria-label="GitHub Profile"
            >
              <Github className="w-4 h-4" />
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-[#9DA2AC] hover:text-[#F1F1EF] hover:bg-[#1A1C22] border border-[#262830] transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#16171B] border-b border-[#262830] px-4 pt-3 pb-6 shadow-2xl">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-3 py-2 text-xs font-mono-custom tracking-wider rounded-md transition-colors flex items-center justify-between ${
                    isActive
                      ? 'text-[#F1F1EF] bg-[#1D1F25] font-bold border-l-2 border-[#D4A373]'
                      : 'text-[#9DA2AC] hover:text-[#F1F1EF] hover:bg-[#1A1C22]'
                  }`}
                >
                  <span>{link.name}</span>
                  {isActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4A373]" />
                  )}
                </a>
              );
            })}
          </nav>

          <div className="mt-4 pt-4 border-t border-[#262830] flex flex-col gap-2.5">
            <div className="flex items-center gap-2.5">
              <a
                href="https://github.com/Zaid70-star"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-mono-custom text-[#D4A373] bg-[#1B1D23] rounded-md border border-[#2E323D] hover:text-white"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GITHUB</span>
              </a>
              <a
                href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-mono-custom text-[#F1F1EF] bg-[#1B1D23] rounded-md border border-[#2E323D] hover:text-white"
              >
                <Linkedin className="w-3.5 h-3.5" />
                <span>LINKEDIN</span>
              </a>
            </div>

            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-md transition-colors text-center"
            >
              <span>Let's Work Together</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

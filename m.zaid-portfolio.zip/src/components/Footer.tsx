import React from 'react';
import { Github, Linkedin, Mail, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0E0F12] border-t border-[#202228] py-12 text-[#9DA2AC]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[#202228]">
          {/* Identity Wordmark */}
          <div className="text-center md:text-left">
            <a href="#home" className="text-lg font-bold text-[#F1F1EF] hover:text-[#D4A373] transition-colors">
              Muhammad Zaid
            </a>
            <p className="text-xs text-[#9DA2AC] font-mono-custom mt-1">
              Frontend Developer | AI Integration | Automation
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-2.5 text-xs font-mono-custom">
            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#16171B] rounded border border-[#262830] hover:border-[#383C48] transition-colors"
              aria-label="GitHub Profile"
              title="GitHub Profile (Zaid70-star)"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#16171B] rounded border border-[#262830] hover:border-[#383C48] transition-colors"
              aria-label="LinkedIn Profile"
              title="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href="mailto:mzaidi1326@gmail.com"
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#16171B] rounded border border-[#262830] hover:border-[#383C48] transition-colors"
              aria-label="Direct Email"
              title="mzaidi1326@gmail.com"
            >
              <Mail className="w-4 h-4" />
            </a>

            <button
              type="button"
              onClick={scrollToTop}
              className="p-2 text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#16171B] rounded border border-[#262830] hover:border-[#383C48] transition-colors ml-1"
              title="Back to Top"
              aria-label="Scroll back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom Bar with Dynamic Year */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#686D78] gap-3">
          <p>© {currentYear} Muhammad Zaid. All rights reserved.</p>
          <p className="font-mono-custom text-[11px] text-[#686D78]">
            Lahore, Pakistan · Built with React, TypeScript &amp; Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
};

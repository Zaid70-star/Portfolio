import React from 'react';
import { BUILDING_MILESTONES } from '../data/experience';
import { Sparkles, Code2, GraduationCap } from 'lucide-react';

export const Experience: React.FC = () => {
  return (
    <section id="building" className="py-20 bg-[#111215]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
            Experience &amp; Progression
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight">
            Building &amp; Learning
          </h2>
          <p className="text-sm text-[#9DA2AC] mt-2">
            A transparent timeline of my Computer Science coursework, practical project builds, freelance problem solving, and technological expansion.
          </p>
        </div>

        {/* Timeline Grid */}
        <div className="relative border-l border-[#262830] ml-4 sm:ml-6 pl-6 sm:pl-8 space-y-10">
          {BUILDING_MILESTONES.map((item, idx) => (
            <div key={idx} className="relative group">
              {/* Timeline Indicator Dot */}
              <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-3.5 h-3.5 rounded-full bg-[#111215] border-2 border-[#D4A373] group-hover:bg-[#D4A373] transition-colors" />

              <div className="p-6 rounded-xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] transition-all">
                {/* Meta Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-mono-custom text-[#D4A373] bg-[#D4A373]/10 px-2 py-0.5 rounded border border-[#D4A373]/25">
                    {item.period}
                  </span>
                  <span className="text-xs font-mono-custom text-[#686D78]">
                    {item.focus}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-[#F1F1EF] mb-2 tracking-tight">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#9DA2AC] leading-relaxed mb-4">
                  {item.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] font-mono-custom px-2 py-0.5 rounded bg-[#111215] text-[#9DA2AC] border border-[#262830]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Education & Continuous Development Summary Banner */}
        <div className="mt-12 p-6 rounded-xl bg-[#16171B] border border-[#262830] grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-[#9DA2AC]">
          <div className="flex items-start gap-3">
            <GraduationCap className="w-5 h-5 text-[#D4A373] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#F1F1EF]">Degree Program</p>
              <p className="text-[#9DA2AC] mt-0.5">BS Computer Science at UET Lahore, expected graduation 2029.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Code2 className="w-5 h-5 text-[#D4A373] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#F1F1EF]">Project-First Philosophy</p>
              <p className="text-[#9DA2AC] mt-0.5">Every concept learned is tested and consolidated through practical, working repositories.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-[#D4A373] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#F1F1EF]">Current Trajectory</p>
              <p className="text-[#9DA2AC] mt-0.5">Advancing Python/FastAPI microservices, frontend systems, and automated n8n pipelines.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

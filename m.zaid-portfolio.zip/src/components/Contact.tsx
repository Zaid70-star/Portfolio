import React, { useState } from 'react';
import { Mail, Github, Linkedin, Copy, Check, Send, MapPin, Sparkles, AlertCircle } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: 'Modern Website Development',
    message: '',
  });

  const [copiedEmail, setCopiedEmail] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const directEmail = 'mzaidi1326@gmail.com';

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(directEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Project Inquiry: ${formData.projectType} — from ${formData.name}`);
    const body = encodeURIComponent(
      `Hello Muhammad Zaid,\n\nMy name: ${formData.name}\nMy email: ${formData.email}\nProject Type: ${formData.projectType}\n\nMessage:\n${formData.message}`
    );
    window.location.href = `mailto:${directEmail}?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-[#111215]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#D4A373] tracking-wider mb-2">
            Get in Touch
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F1F1EF] tracking-tight">
            Let's Build Something Useful.
          </h2>
          <p className="text-base text-[#9DA2AC] mt-2">
            Have a website, AI feature, or automation idea? Let's talk.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Direct Contact Details (Cols 1-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-[#16171B] border border-[#262830] space-y-4">
              <h3 className="text-base font-semibold text-[#F1F1EF]">Direct Communication</h3>
              <p className="text-xs text-[#9DA2AC] leading-relaxed">
                Feel free to email me directly or connect via GitHub and LinkedIn. I typically reply within 24 hours.
              </p>

              {/* Email Row with Copy Button */}
              <div className="p-3.5 rounded-xl bg-[#111215] border border-[#262830] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <Mail className="w-4 h-4 text-[#D4A373] shrink-0" />
                  <span className="text-xs sm:text-sm font-mono-custom text-[#F1F1EF] truncate">
                    {directEmail}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="px-2.5 py-1 text-xs font-mono-custom text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#1B1D23] hover:bg-[#22252E] rounded border border-[#2E323D] transition-colors inline-flex items-center gap-1 shrink-0"
                  title="Copy email to clipboard"
                >
                  {copiedEmail ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#A8C5A0]" />
                      <span className="text-[#A8C5A0]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              {/* Location & Availability */}
              <div className="space-y-2 pt-2 text-xs text-[#9DA2AC]">
                <div className="flex items-center gap-2.5">
                  <MapPin className="w-4 h-4 text-[#686D78] shrink-0" />
                  <span>Lahore, Pakistan · Available Worldwide (Remote)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#686D78] shrink-0" />
                  <span>Available for Freelance, Internships &amp; Junior Roles</span>
                </div>
              </div>
            </div>

            {/* Quick Links Card */}
            <div className="p-6 rounded-2xl bg-[#16171B] border border-[#262830]">
              <h4 className="text-xs font-mono-custom text-[#686D78] uppercase tracking-wider mb-3">
                Profiles &amp; Verification
              </h4>
              <div className="flex flex-col gap-2.5 text-xs">
                <a
                  href="https://github.com/Zaid70-star"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between text-[#9DA2AC] hover:text-[#F1F1EF] group transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Github className="w-4 h-4 text-[#686D78] group-hover:text-[#D4A373] transition-colors" />
                    <span>github.com/Zaid70-star</span>
                  </span>
                  <span className="text-[11px] font-mono-custom text-[#686D78] group-hover:text-[#D4A373]">
                    Repositories →
                  </span>
                </a>

                <a
                  href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between text-[#9DA2AC] hover:text-[#F1F1EF] group transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Linkedin className="w-4 h-4 text-[#686D78] group-hover:text-[#D4A373] transition-colors" />
                    <span>LinkedIn Profile</span>
                  </span>
                  <span className="text-[11px] font-mono-custom text-[#686D78] group-hover:text-[#D4A373]">
                    Connect →
                  </span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Project Inquiry Form (Cols 6-12) */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#16171B] border border-[#262830] relative">
              <h3 className="text-lg font-bold text-[#F1F1EF] mb-1">Send a Project Inquiry</h3>
              <p className="text-xs text-[#9DA2AC] mb-6">
                Fill in the details below. This form pre-configures your email client directly to start our conversation.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name Input */}
                  <div>
                    <label htmlFor="name" className="block text-xs font-mono-custom text-[#9DA2AC] uppercase tracking-wider mb-1.5">
                      Your Name
                    </label>
                    <input
                      id="name"
                      type="text"
                      required
                      placeholder="e.g. Sarah Jenkins"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#111215] border border-[#262830] rounded-lg text-[#F1F1EF] placeholder-[#686D78] focus:outline-none focus:border-[#D4A373] transition-colors"
                    />
                  </div>

                  {/* Email Input */}
                  <div>
                    <label htmlFor="email" className="block text-xs font-mono-custom text-[#9DA2AC] uppercase tracking-wider mb-1.5">
                      Your Email Address
                    </label>
                    <input
                      id="email"
                      type="email"
                      required
                      placeholder="e.g. sarah@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#111215] border border-[#262830] rounded-lg text-[#F1F1EF] placeholder-[#686D78] focus:outline-none focus:border-[#D4A373] transition-colors"
                    />
                  </div>
                </div>

                {/* Project Type Select */}
                <div>
                  <label htmlFor="projectType" className="block text-xs font-mono-custom text-[#9DA2AC] uppercase tracking-wider mb-1.5">
                    Project Type
                  </label>
                  <select
                    id="projectType"
                    value={formData.projectType}
                    onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#111215] border border-[#262830] rounded-lg text-[#F1F1EF] focus:outline-none focus:border-[#D4A373] transition-colors"
                  >
                    <option value="Modern Website Development">Modern Website Development (React &amp; Tailwind)</option>
                    <option value="AI Chatbot Integration">AI Chatbot Integration (Gemini API &amp; FastAPI)</option>
                    <option value="AI Feature Integration">AI Feature Integration (Prompt Engineering &amp; APIs)</option>
                    <option value="Workflow Automation">Workflow Automation (n8n &amp; Webhooks)</option>
                    <option value="REST API Integration">REST API Integration</option>
                    <option value="Website Redesign">Website Redesign &amp; Responsive UI</option>
                    <option value="Other Project Inquiry">Other Project Inquiry</option>
                  </select>
                </div>

                {/* Message Textarea */}
                <div>
                  <label htmlFor="message" className="block text-xs font-mono-custom text-[#9DA2AC] uppercase tracking-wider mb-1.5">
                    Project Overview / Message
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={4}
                    placeholder="Briefly describe what you would like to build or automate..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#111215] border border-[#262830] rounded-lg text-[#F1F1EF] placeholder-[#686D78] focus:outline-none focus:border-[#D4A373] transition-colors resize-none"
                  />
                </div>

                {/* Submit Action */}
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-lg transition-all shadow-sm active:translate-y-0.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message via Email Client</span>
                </button>

                {submitted && (
                  <div className="p-3 bg-[#A8C5A0]/10 border border-[#A8C5A0]/25 rounded-lg text-xs text-[#A8C5A0] flex items-center gap-2">
                    <Check className="w-4 h-4 shrink-0" />
                    <span>Your email draft has been generated! You can also email directly to {directEmail}.</span>
                  </div>
                )}

                {/* Integration Note */}
                <div className="pt-3 border-t border-[#262830] flex items-start gap-2 text-[11px] text-[#686D78] font-mono-custom">
                  <AlertCircle className="w-3.5 h-3.5 text-[#686D78] shrink-0 mt-0.5" />
                  <span>
                    Form is pre-structured for seamless drop-in integration with Formspree, Resend, or EmailJS when deployed to production.
                  </span>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

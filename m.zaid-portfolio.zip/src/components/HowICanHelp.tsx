import React from 'react';
import { ArrowUpRight, MessageSquareCode } from 'lucide-react';

export const HowICanHelp: React.FC = () => {
  return (
    <section className="py-16 bg-[#131418] border-b border-[#262830]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-10 rounded-2xl bg-[#16171B] border border-[#262830] relative overflow-hidden">
          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-mono-custom text-[#D4A373] bg-[#D4A373]/10 border border-[#D4A373]/25 rounded-full mb-4">
              <MessageSquareCode className="w-3.5 h-3.5" />
              <span>Direct Collaboration</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-bold text-[#F1F1EF] tracking-tight leading-snug mb-3">
              Have a website idea or repetitive business process?
            </h3>

            <p className="text-base text-[#9DA2AC] leading-relaxed mb-6">
              I can help turn it into a modern web experience or automate the repetitive parts using APIs, AI, and workflows. Whether you need a fresh React interface, a custom AI chatbot endpoint, or an n8n webhook pipeline, let's discuss your requirements.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-lg transition-all shadow-sm active:translate-y-0.5"
              >
                <span>Start a Conversation</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://github.com/Zaid70-star"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 text-xs font-mono-custom text-[#9DA2AC] hover:text-[#F1F1EF] bg-[#1B1D23] hover:bg-[#22252E] rounded-lg border border-[#2E323D] transition-colors"
              >
                <span>Browse Code on GitHub</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

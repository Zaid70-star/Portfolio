import React from 'react';
import { Github, Linkedin, ArrowUpRight, FolderGit2, Star, GitBranch } from 'lucide-react';

export const SocialHub: React.FC = () => {
  return (
    <section className="py-16 bg-[#131418] border-y border-[#262830]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* GitHub Highlight Card */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-xl bg-[#1B1D23] border border-[#2E323D] text-[#D4A373]">
                  <Github className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono-custom text-[#D4A373] bg-[#D4A373]/10 px-2 py-0.5 rounded border border-[#D4A373]/25">
                  @Zaid70-star
                </span>
              </div>

              <h3 className="text-xl font-bold text-[#F1F1EF] mb-2">GitHub Profile &amp; Repositories</h3>
              <p className="text-xs sm:text-sm text-[#9DA2AC] leading-relaxed mb-6">
                Explore my public codebases including React web applications, FastAPI backends, Gemini AI prompt experiments, and n8n workflow diagrams.
              </p>

              <div className="grid grid-cols-3 gap-3 p-3 bg-[#111215] border border-[#262830] rounded-xl mb-6 text-center text-xs">
                <div>
                  <div className="flex items-center justify-center gap-1 text-[#686D78] font-mono-custom mb-1">
                    <FolderGit2 className="w-3.5 h-3.5" />
                  </div>
                  <p className="font-semibold text-[#F1F1EF]">Public Repos</p>
                  <p className="text-[11px] text-[#686D78]">React &amp; Python</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-[#686D78] font-mono-custom mb-1">
                    <GitBranch className="w-3.5 h-3.5" />
                  </div>
                  <p className="font-semibold text-[#F1F1EF]">Active Code</p>
                  <p className="text-[11px] text-[#686D78]">Regular Commits</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-[#686D78] font-mono-custom mb-1">
                    <Star className="w-3.5 h-3.5 text-[#D4A373]" />
                  </div>
                  <p className="font-semibold text-[#F1F1EF]">Open Source</p>
                  <p className="text-[11px] text-[#686D78]">Job Finder &amp; AI</p>
                </div>
              </div>
            </div>

            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-[#F1F1EF] bg-[#1B1D23] hover:bg-[#22252E] hover:text-white rounded-lg border border-[#2E323D] transition-colors"
            >
              <span>View GitHub (Zaid70-star)</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>

          {/* LinkedIn Highlight Card */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#16171B] border border-[#262830] hover:border-[#383C48] transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-xl bg-[#1B1D23] border border-[#2E323D] text-[#D4A373]">
                  <Linkedin className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono-custom text-[#D4A373] bg-[#D4A373]/10 px-2 py-0.5 rounded border border-[#D4A373]/25">
                  Professional Network
                </span>
              </div>

              <h3 className="text-xl font-bold text-[#F1F1EF] mb-2">Connect on LinkedIn</h3>
              <p className="text-xs sm:text-sm text-[#9DA2AC] leading-relaxed mb-6">
                Open to discussions with engineering recruiters, startup founders, freelance clients, and fellow software engineers regarding web, AI, and automation projects.
              </p>

              <div className="p-4 bg-[#111215] border border-[#262830] rounded-xl mb-6 text-xs text-[#9DA2AC] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[#686D78]">Target Opportunities:</span>
                  <span className="font-medium text-[#F1F1EF]">Freelance &amp; Junior Roles</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#686D78]">Location:</span>
                  <span className="font-medium text-[#F1F1EF]">Lahore, Pakistan (Remote Open)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#686D78]">Communication:</span>
                  <span className="font-medium text-[#F1F1EF]">English / Urdu</span>
                </div>
              </div>
            </div>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-[#111215] bg-[#F1F1EF] hover:bg-white rounded-lg transition-colors shadow-sm"
            >
              <span>Connect on LinkedIn</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

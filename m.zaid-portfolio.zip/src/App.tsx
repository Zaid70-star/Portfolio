import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Services } from './components/Services';
import { HowICanHelp } from './components/HowICanHelp';
import { Experience } from './components/Experience';
import { SocialHub } from './components/SocialHub';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#111215] text-[#F1F1EF] selection:bg-[#D4A373]/25 selection:text-[#F1F1EF]">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Services />
        <HowICanHelp />
        <Experience />
        <SocialHub />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

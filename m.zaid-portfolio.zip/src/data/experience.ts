import { BuildingMilestone } from '../types';

export const BUILDING_MILESTONES: BuildingMilestone[] = [
  {
    period: '2025 – Present',
    title: 'Computer Science Undergraduate Studies',
    focus: 'UET Lahore — BS Computer Science',
    description:
      'Pursuing a comprehensive Computer Science curriculum focusing on core data structures, algorithms, object-oriented programming (C++), and modern software engineering principles.',
    tags: ['Data Structures', 'Algorithms', 'C++', 'OOP', 'SQL Foundations'],
  },
  {
    period: '2024 – Present',
    title: 'Practical Frontend & Web Development',
    focus: 'React & Component-Driven Applications',
    description:
      'Designing and developing client-side web applications using React, Vite, React Router, and Tailwind CSS. Implementing dynamic routing, responsive design systems, client state management, and third-party REST API consumption.',
    tags: ['React', 'JavaScript', 'Tailwind CSS', 'Vite', 'REST APIs'],
  },
  {
    period: '2024 – Present',
    title: 'AI Integrations & API Services',
    focus: 'Gemini API & Python/FastAPI Backend Engineering',
    description:
      'Building backend microservices with Python and FastAPI to integrate Google’s Gemini API. Crafting structured system prompts, handling streaming/asynchronous responses, and embedding AI-assisted generation into web interfaces.',
    tags: ['Gemini API', 'Python', 'FastAPI', 'Prompt Engineering', 'Firebase'],
  },
  {
    period: '2024 – Present',
    title: 'Workflow Automation & Tool Integration',
    focus: 'n8n & Process Orchestration',
    description:
      'Developing automated workflows that link webhooks, third-party APIs, and AI processing nodes in n8n. Eliminating manual administrative tasks such as lead sorting, webhook routing, and multi-service syncing.',
    tags: ['n8n', 'Webhooks', 'API Automation', 'JSON Parsing'],
  },
];

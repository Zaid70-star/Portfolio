import { Project } from '../types';

export const FEATURED_PROJECTS: Project[] = [
  {
    id: 'job-finder',
    name: 'Job Finder',
    tagline: 'Search, review, and persist job opportunities with a responsive client interface',
    description:
      'A responsive job-search web application built with React that allows users to search open positions, inspect comprehensive job details, bookmark listings to local storage, and navigate between views smoothly.',
    technologies: ['React', 'Vite', 'React Router', 'Tailwind CSS', 'REST API', 'LocalStorage', 'Netlify'],
    features: [
      'Keyword & criteria search with live filtering across job listings',
      'Comprehensive job details view powered by dynamic React Router routes',
      'Persistent saved jobs collection preserved via browser LocalStorage',
    ],
    githubUrl: 'https://github.com/Zaid70-star/Job-Finder',
    demoUrl: 'https://github.com/Zaid70-star/Job-Finder',
    category: 'web',
    architectureNotes: 'React Client + REST API + LocalStorage state layer',
  },
  {
    id: 'ai-web-app',
    name: 'AI Web Application',
    tagline: 'Idea and content generation system with authentication and real-time dashboard',
    description:
      'An AI-powered web application that integrates user authentication, database persistence, interactive AI generation workflows, and a centralized management dashboard for generated content.',
    technologies: ['React', 'Firebase', 'AI API', 'JavaScript', 'Tailwind CSS'],
    features: [
      'User authentication and account management powered by Firebase',
      'Interactive AI chatbot and dynamic content generation tools',
      'Real-time Firestore persistence with historical dashboard views',
    ],
    demoUrl: 'https://aiideaandcontentgenerate.netlify.app/',
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'ai',
    badge: 'Live Demo Available',
    architectureNotes: 'React SPA + Firebase Auth/DB + Generative AI REST endpoints',
  },
  {
    id: 'ai-chatbot-api',
    name: 'AI Chatbot & API Backend',
    tagline: 'FastAPI microservice connected to the Gemini API with structured prompting',
    description:
      'An AI chatbot application leveraging a Python and FastAPI backend microservice to manage communication with Google’s Gemini API, implementing prompt engineering to deliver structured, contextual answers.',
    technologies: ['Python', 'FastAPI', 'Gemini API', 'REST API', 'JavaScript'],
    features: [
      'High-throughput asynchronous FastAPI endpoints for conversation processing',
      'Direct Gemini API integration with tailored contextual prompt instructions',
      'Clean JSON contract facilitating seamless frontend/backend data exchange',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'ai',
    architectureNotes: 'FastAPI ASGI service + Google Gemini API + Client interface',
  },
  {
    id: 'ecommerce-store',
    name: 'E-Commerce Store',
    tagline: 'Responsive product marketplace with catalog filtering and client cart state',
    description:
      'A responsive e-commerce application featuring product catalog browsing, detailed item inspections, a functional shopping cart, and wishlist management connected to external product endpoints.',
    technologies: ['React', 'Tailwind CSS', 'DummyJSON API', 'Context API', 'JavaScript'],
    features: [
      'Dynamic product browsing and search with category filtration',
      'Shopping cart state management handled with React Context API',
      'Wishlist preservation and fluid responsive mobile-first layouts',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'web',
    architectureNotes: 'React Context architecture + DummyJSON REST catalog',
  },
  {
    id: 'n8n-automation',
    name: 'n8n Workflow Automation',
    tagline: 'Multi-service automation linking incoming webhooks, AI processing, and APIs',
    description:
      'An automation workflow engineered in n8n designed to connect external webhooks, API endpoints, and AI summarization to automate repetitive data collection and notification tasks.',
    technologies: ['n8n', 'APIs', 'Webhooks', 'AI Integration', 'JSON'],
    features: [
      'Webhook listener routing incoming business triggers to downstream tasks',
      'AI prompt node extracting structured attributes from unstructured messages',
      'Automated API dispatch eliminating manual copy-paste workflows',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'automation',
    architectureNotes: 'Trigger Webhook → AI Processing Node → Downstream API payload',
  },
];

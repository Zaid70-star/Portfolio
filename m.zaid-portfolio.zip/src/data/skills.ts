import { SkillCategory } from '../types';

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Frontend Development',
    id: 'frontend',
    description: 'Component architecture, responsive layouts, and interactive client state.',
    skills: [
      { name: 'React', highlight: true },
      { name: 'JavaScript (ES6+)', highlight: true },
      { name: 'HTML5 & Semantic DOM' },
      { name: 'CSS3 & Modern Layouts' },
      { name: 'Tailwind CSS', highlight: true },
      { name: 'React Router' },
      { name: 'DOM Manipulation' },
      { name: 'Responsive Web Design', highlight: true },
    ],
  },
  {
    title: 'Backend & APIs',
    id: 'backend',
    description: 'RESTful API construction, server services, and lightweight persistence.',
    skills: [
      { name: 'Python', highlight: true },
      { name: 'FastAPI', highlight: true },
      { name: 'REST APIs', highlight: true },
      { name: 'Firebase' },
      { name: 'SQL', note: 'Basic' },
    ],
  },
  {
    title: 'AI & Machine Intelligence',
    id: 'ai',
    description: 'Practical integration of generative AI models, chat interfaces, and endpoints.',
    skills: [
      { name: 'Gemini API', highlight: true },
      { name: 'AI API Integration', highlight: true },
      { name: 'AI Chatbots', highlight: true },
      { name: 'Prompt Engineering' },
      { name: 'Basic AI Agents' },
      { name: 'AI-Powered Web Apps', highlight: true },
    ],
  },
  {
    title: 'Automation & Workflows',
    id: 'automation',
    description: 'Streamlining repetitive operations through webhooks and integration platforms.',
    skills: [
      { name: 'n8n', highlight: true },
      { name: 'Workflow Automation', highlight: true },
      { name: 'API Automation' },
      { name: 'Lead Generation Automation' },
      { name: 'AI Workflow Integration', highlight: true },
    ],
  },
  {
    title: 'Engineering Tools & Foundations',
    id: 'tools',
    description: 'Version control, developer toolchains, and programming paradigms.',
    skills: [
      { name: 'Git & GitHub', highlight: true },
      { name: 'Netlify' },
      { name: 'VS Code' },
      { name: 'C++' },
      { name: 'Object-Oriented Programming (OOP)' },
    ],
  },
];

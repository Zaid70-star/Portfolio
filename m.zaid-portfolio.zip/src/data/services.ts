import { Service } from '../types';

export const SERVICES: Service[] = [
  {
    id: 'web-dev',
    title: 'Modern Website Development',
    problem: 'Outdated, sluggish, or unresponsive sites that fail to represent your brand and lose mobile visitors.',
    solution: 'Build fast, responsive, component-driven websites that look polished on every screen size and load quickly.',
    technologies: ['React', 'JavaScript', 'Tailwind CSS', 'Vite'],
    icon: 'Layout',
  },
  {
    id: 'ai-chatbots',
    title: 'AI Chatbot Integration',
    problem: 'Visitors leave websites without answers to basic questions, and staff spend time answering the same inquiries.',
    solution: 'Integrate conversational AI chat assistants that answer user questions instantly using AI models and structured system prompts.',
    technologies: ['Gemini API', 'Python / FastAPI', 'REST APIs', 'React'],
    icon: 'BotMessageSquare',
  },
  {
    id: 'ai-features',
    title: 'AI Feature Integration',
    problem: 'Existing web applications lack modern AI utilities that could summarize data, draft content, or extract insights.',
    solution: 'Add practical, targeted AI capabilities directly into existing web apps via clean API connections without re-architecting your entire stack.',
    technologies: ['Gemini API', 'Prompt Engineering', 'REST APIs'],
    icon: 'Sparkles',
  },
  {
    id: 'workflow-automation',
    title: 'Workflow Automation',
    problem: 'Teams waste hours every week copying data across tools, forwarding notifications, or manually compiling reports.',
    solution: 'Construct reliable n8n workflows that connect disparate apps, listen to webhooks, process data with AI, and dispatch automated actions.',
    technologies: ['n8n', 'Webhooks', 'REST APIs', 'JSON'],
    icon: 'Workflow',
  },
  {
    id: 'api-integration',
    title: 'API Integration',
    problem: 'Frontends and client dashboards that are isolated from third-party services, databases, or payment/data endpoints.',
    solution: 'Wire frontends to external REST APIs and backend endpoints with error handling, loading states, and clean data mapping.',
    technologies: ['REST APIs', 'FastAPI', 'Fetch / Axios', 'JSON'],
    icon: 'Cpu',
  },
  {
    id: 'website-redesign',
    title: 'Website Redesign',
    problem: 'Cluttered visual layouts, poor typography, and legacy styling that look unprofessional to prospective clients or customers.',
    solution: 'Refactor and redesign outdated pages into clean, minimal interfaces with modern typography, refined spacing, and mobile polish.',
    technologies: ['Tailwind CSS', 'React', 'Responsive Design', 'HTML/CSS'],
    icon: 'Palette',
  },
];

export interface Project {
  id: string;
  name: string;
  tagline: string;
  description: string;
  technologies: string[];
  features: string[];
  githubUrl?: string;
  demoUrl?: string;
  category: 'web' | 'ai' | 'automation';
  badge?: string;
  architectureNotes?: string;
}

export interface SkillCategory {
  title: string;
  id: string;
  description: string;
  skills: {
    name: string;
    note?: string; // e.g. "Practical / Working Knowledge" or "Basic"
    highlight?: boolean;
  }[];
}

export interface Service {
  id: string;
  title: string;
  problem: string;
  solution: string;
  technologies: string[];
  icon: string;
}

export interface BuildingMilestone {
  period: string;
  title: string;
  focus: string;
  description: string;
  tags: string[];
}
